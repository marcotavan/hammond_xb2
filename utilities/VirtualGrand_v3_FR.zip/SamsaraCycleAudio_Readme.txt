Samsara Cycle Audio

VIRTUAL INSTRUMENTS AND EFFECTS

� Samsara Cycle Audio 2015

--------------

Install notes:

Copy the .dll file to your VST folder and load in your DAW software. Ensure the folder has full write permissions set. Contact me via my website at: http://samcycle.blogspot.com if you require further information.

--------------------------------------------------------

Please send any presets or links music you create with my plug-ins to me via http://samcycle.blogspot.com I will add them to the list of free downloads so all users of the plug-ins may benefit :)

Donations are very welcome in appreciation of my time and dedication to creating this plug-in and many others. The price of a cup of coffee

It is easy and secure to donate by clicking on the PayPal Donate button at http://samcycle.blogspot.com or directly to my PayPal account: samcaudio@gmail.com

You don�t need a PayPal account to make a secure donation

THANK YOU AND ENJOY

NAMASTE